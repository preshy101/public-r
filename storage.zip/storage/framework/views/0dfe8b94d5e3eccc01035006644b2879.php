

<div> 
	
    
    <section class="hero-area"> 
		<div id="corporex-slider" class="corporex-slider corporex-slider-03 carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
				<!--[if BLOCK]><![endif]--><?php if($slide): ?> 
				<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				<li data-target="#corporex-slider" data-slide-to="<?php echo e($index); ?>" class="<?php echo e(( $index == 0 )? 'active':''); ?>"></li>
			
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->	
			
			</ol> <!-- .carousel-indicators -->
			 
			<div class="carousel-inner">

				

				<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				<div class="item caption-left gradient-left-dark <?php echo e(( $index == 0 )? 'active':''); ?>" > 
					<img class="slider-bg img-responsive" 
					src="<?php echo e(Storage::url($item->image)); ?>"  
					alt="slider image 01">
					<div class="container">
						
						<div class="carousel-caption">
							<h1 class="h1-extra">
								
								<?php echo e($item->title); ?></h1>
							<p class="lead" style="color: white;">
								<?php echo $item->description; ?>

							</p> 
							
						</div> <!-- .carousel-caption -->
					</div> <!-- .container -->
				</div> <!-- .item -->
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
			
			</div> <!-- .carousel-inner -->

			<!-- Controls -->
  			<a class="left carousel-control" href="#corporex-slider" role="button" data-slide="prev">
  				<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
  				<span class="sr-only">Previous</span>
  			</a> <!-- .carousel-control -->

  			<a class="right carousel-control" href="#corporex-slider" role="button" data-slide="next">
  				<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
  				<span class="sr-only">Previous</span>
  			</a> <!-- .carousel-control -->
	<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
		</div> <!-- .carousel -->
	</section> <!-- .hero-area -->
	<!-- Slideshow container -->
	 

    
	<section class="intro-section intro-08 section-block">
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1 text-block text-center">
					<h2><span>WELCOME TO THE</span> NIGERIAN INSTITUTE OF PUBLIC RELATIONS (NIPR)</h2>
					<p class="lead">
						
						<?php echo e(($welcome != null)?$welcome->description:""); ?>

					</p>
				</div> <!-- .col-md-8 img-block -->
			</div> <!-- .row -->
			<div class="row feature-set">
				<div class="col-sm-4">
					<div class="item-wrapper">
						<div class="icon-box"><i class="pe-7s-rocket"></i></div>
						<div class="content-wrapper">
							<h3>Career Road-map</h3>
							<p>
								Navigate your professional journey with our comprehensive career roadmap, designed to guide you through strategic milestones and opportunities for growth.							</p>
						</div> <!-- .content-wrapper -->
					</div> <!-- .item-wrapper -->
				</div> <!-- .col-sm-4 -->
				<div class="col-sm-4">
					<div class="item-wrapper">
						<div class="icon-box"><i class="pe-7s-shield"></i></div>
						<div class="content-wrapper">
							<h3>Security</h3>
							<p>
								Ensuring your safety in the digital realm, we prioritize robust security measures to safeguard your information and provide you with a secure online experience.							</p>
						</div> <!-- .content-wrapper -->
					</div> <!-- .item-wrapper -->
				</div> <!-- .col-sm-4 -->
				<div class="col-sm-4">
					<div class="item-wrapper">
						<div class="icon-box"><i class="pe-7s-ribbon"></i></div>
						<div class="content-wrapper">
							<h3>Certification</h3>
							<p>
								Elevate your expertise and credibility with our range of industry-recognized certifications, empowering you to stay ahead in today's competitive landscape							</p>
						</div> <!-- .content-wrapper -->
					</div> <!-- .item-wrapper -->
				</div> <!-- .col-sm-4 -->
			</div> <!-- .row -->
		</div> <!-- .container -->
	</section> <!-- .about-section -->

    
	<section class="fun-facts-section fun-facts-01 section-block">
        <div class="container">
            <div class="row">
                <div class="col-md-6 content-block">
                    <h2><span>Professionalism at its best</span>Our excellent records preceeds us</h2>
					<p>
						With a track record of excellence, our commitment to quality and innovation is reflected in our records, 
						showcasing a history of successful partnerships and satisfied clients 
					</p>
				</div> <!-- .col-md-6 -->
				<div class="col-md-5 col-md-offset-1 facts-block">
                    <div class="row">
                        <div class="col-xs-6">
                            <i class="pe-7s-user"></i>
							<h3><span class="counter">15455</span>Students</h3>
						</div> <!-- .col-xs-6 -->
						<div class="col-xs-6">
                            <i class="pe-7s-users"></i>
							<h3><span class="counter">7464</span>Members</h3>
						</div> <!-- .col-xs-6 -->
						<div class="col-xs-6">
                            <i class="pe-7s-note"></i>
							<h3><span class="counter">2432</span>Certificates</h3>
						</div> <!-- .col-xs-6 -->
						<div class="col-xs-6">
                            <i class="pe-7s-camera"></i>
							<h3><span class="counter">43</span>Events</h3>
						</div> <!-- .col-xs-6 -->
					</div> <!-- .row -->
					
				</div> <!-- .col-md-6 -->
			</div> <!-- .row -->
		</div> <!-- .container -->
	</section> <!-- .split-section -->

	
	<section class="contact-banner" style="background-color: red">
			<div class="container">
				<h2>Make the first step </h2>
				<p>Its easy and beautiful. It will change your life</p>
				<a class="contact-btn btn btn-ghost" id="contact" style="co" href="#">Become a Member</a>
			</div> <!-- .container -->
	</section> <!-- .contact-banner -->

	
		<?php echo $__env->make('livewire.sections.presidentMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <section class="accordion-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="panel-group corporex-accordion accordion-style-01 radial" id="accordion">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
						<div class="panel">
                            <div class="panel-heading <?php echo e(($index == 0)? 'active':''); ?>">
                                <h4 class="panel-title">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($index); ?>">
                                       <?php echo e($item->title); ?>

                                    </a>
                                </h4><!-- .panel-title -->
                            </div> <!-- .panel-heading -->
                            <div id="collapse<?php echo e($index); ?>" class="panel-collapse collapse <?php echo e(($index == 0)? 'in':''); ?>">
                                <div class="panel-body">
                                    <p>
                                        <?php echo e($item->description); ?>

                                    </p>
                                </div> <!-- .panel-body -->
                            </div> <!-- .panel-collapse -->
                        </div> <!-- .panel panel-default --> 
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]--> 
 
                    </div> <!-- .panel-group -->
                </div> <!-- .col-md-6 -->
                <div class="col-md-6">
                    <div class="image-wrapper">
                        <img class="img-responsive" src="<?php echo e(asset('./img/simone-secci-49uySSA678U-unsplash.jpg')); ?>" alt="hand shake image">
                    </div> <!-- .img-wrapper -->
                </div> <!-- .col-md-6 -->
            </div> <!-- .row -->
        </div> <!-- .container -->
    </section> <!-- .accordion-section -->

    
	<section class="testimonial-section section-block" style="background-color: red" >
		<div class="container" >
			<div class="title-block white"  >
				<h2>What people say</h2>
				<p>
					Clients consistently commend us for our unwavering commitment to excellence, personalized service, and our ability to exceed expectations,
					 making us a trusted partner in their success stories
				</p>
			</div> <!-- .title-block -->
			<div class="testimonial-carousel" id="testimonial-carousel">
				<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $testimony; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				<div class="testimonial-item">
					<div class="content-wrapper">
						<div class="image-wrapper">
							<img class="img-responsive" 
							src="<?php echo e(Storage::url($item->image)); ?>" 
							style="width:72px; height: 72px;" alt="quote author 01"></div>
						<blockquote>
							<?php echo e($item->description); ?>

						</blockquote>
						<h4><?php echo e($item->title); ?>

							
						</h4>
					</div> <!-- .content-wrapper -->
				</div> <!-- .col-md-4 -->
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
				 
			</div> <!-- .row -->
		</div> <!-- .container -->
	</section> <!-- .testimonial-section -->

    
	<?php echo $__env->make('livewire.sections.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
	
</div>
<?php /**PATH /Users/user/Herd/NIPR-Frontend/NIPR/resources/views/livewire/home.blade.php ENDPATH**/ ?>