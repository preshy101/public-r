<div>
    <?php $__env->startSection('content'); ?>
    <section class="hero-area">
		<div class="page-title-banner" >
			<div class="container">
				<div class="content-wrapper">
					<h2>About Us</h2>
					<ul class="bread-crumb">
						<li><a href="#">Home</a></li>
						<li><a href="#">About</a></li>
					</ul>
				</div> <!-- .content-wrapper -->
			</div> <!-- .container -->
		</div> <!-- .page-title-banner -->
	</section> <!-- .hero-area -->
    <br>
    <br>
    <div class="container">
        <h1 class="entry-title"><a style="color: red" href="#"><?php echo e(($vision != null )?$vision->title:''); ?></a></h1>
        <p class="lead">
         <?php echo e(($vision != null )?$vision->description:''); ?>

        </p>
        <?php echo ($vision != null )?$vision->fullText:''; ?>

    </div>
    <br>
    <br>
    <br>
    
    <?php $__env->stopSection(); ?>
 </div><?php /**PATH /Users/user/Herd/NIPR-Frontend/NIPR/resources/views/livewire/about/Vision-and-mission.blade.php ENDPATH**/ ?>