<div <?php echo e($attributes->class(['flex gap-x-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/user/Herd/NIPR-Frontend/NIPR/vendor/filament/forms/src/../resources/views/components/rich-editor/toolbar/group.blade.php ENDPATH**/ ?>