<div>
    <section class="hero-area">
		<div class="page-title-banner" >
			<div class="container">
				<div class="content-wrapper">
					<h2> News  </h2>
					<ul class="bread-crumb">
						<li><a href="/">Home</a></li>
						<li><a href="#">News</a></li>
					</ul>
				</div> <!-- .content-wrapper -->
			</div> <!-- .container -->
		</div> <!-- .page-title-banner -->
	</section> <!-- .hero-area -->
    <br>
    <br>
    <section class="blog-section blog-post-01 page-content">
		<div class="container">
			
			<div class="row">
				<div class="col-md-8 blog-posts">
		<!--[if BLOCK]><![endif]--><?php if($posts): ?> 
			<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
					<div class="post-wrapper post-split clearfix">
						<div class="image-wrapper">
							<img class="img-responsive" 
							src="<?php echo e(Storage::url($item->image)); ?>" 
							alt="blog image">
						</div> <!-- .image-wrapper -->
						<div class="post-content">
							<ul class="post-meta">
								<li><?php echo e($item->author->name); ?></li>
								<li><?php echo e($item->published_at->diffForHumans()); ?></li>
								
								<li><a href="#"><?php echo e($item->getReadingTime()); ?> minutes read</a></li>
							</ul>
							<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
								<a class="badge badge-pill " style="background: <?php echo e($cat->bg_color); ?>; color:<?php echo e($cat->text_color); ?>" href="#">
									<?php echo e($cat->title); ?>

								</a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
							<h3 class="entry-title"><a  wire:navigate href="/news/posts/<?php echo e($item->slug); ?>"><?php echo e($item->title); ?></a></h3>
							<div class="entry-content">
								<p>
									<?php echo $item->getExcept(); ?>

								</p>
							</div> <!-- .entry-content -->
							<a class="btn btn-main" wire:navigate href="/news/posts/<?php echo e($item->slug); ?>">Read More</a>
						</div> <!-- .post-content -->
					</div> <!-- .post-wrapper split-post -->
	
					
					
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
					
		<?php else: ?>
					
					<div class="col-md-8 blog-posts">
						<p class="lead">No News yet</p>
					</div>	
		<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
					
				</div> <!-- .col-md-8 -->
			
				<?php echo e($posts->links()); ?>

				
				<div class="col-md-4 sidebar">
					<div class="widget widget-search">
						<h3 class="widget-title">Search</h3>
						<form>
							<input class="form-control" type="search" name="search-box" id="search-box" placeholder="Search ..">
							<button class="submit-btn" type="submit"><i class="fa fa-search"></i></button>
						</form>
					</div> <!-- .widget widget-search -->
			
					<div class="widget widget-recent-posts">
						<h3 class="widget-title">Recent Posts</h3>
						<ul class="img-list">
							<!--[if BLOCK]><![endif]--><?php if($recentPosts): ?>
							<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
								<li class="clearfix">
								<img class="img-responsive"  
								src="<?php echo e(Storage::url($item->image)); ?>"  alt="post thumbnail">
								<div class="content-wrapper">
									<h4>
										<a  wire:navigate href="/news/posts/<?php echo e($item->slug); ?>"><?php echo e($item->title); ?> </a>
									</h4>
									<p><?php echo e($item->published_at->diffForHumans()); ?></p>
								</div> <!-- .content-wrapper -->
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
							<?php else: ?>
								<small>No post yet</small>
							<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
							
							 
						</ul>
					</div><!-- .widget widget-recent-posts -->
					
					<div class="widget widget-tags">
						<h3 class="widget-title">Popular Tags</h3>
						<ul>
							<!--[if BLOCK]><![endif]--><?php if($categories): ?>
								<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><a href="#"><?php echo e($item->title); ?></a></li>
									
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
							<?php else: ?>
								<small>No category yet</small>
							<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
							
						</ul>
					</div> <!-- .widget widget-tags -->
			
					<div class="widget widget-social-links">
						<h3 class="widget-title">Follow us</h3>
						<ul>
							<li class="facebook-link"><a href="https://www.facebook.com/profile.php?id=100004381365825&mibextid=AEUHqQ"><i class="fa fa-facebook"></i></a></li>
							<li class="twitter-link"><a href="#https://x.com/nipr_hq?s=11&t=9HmMeHB4scZXQG4gvZuypA"><i class="fa fa-twitter"></i></a></li>
							<li class="google-plus-link"><a href="https://www.linkedin.com/in/niprhq/"><i class="fa fa-linkedin"></i></a></li>
							
							<li class="youtube-link"><a href="https://www.instagram.com/nipr_hq"><i class="fa fa-instagram"></i></a></li>
						</ul>
					</div> <!-- .widget widget-social-links -->
			
					<div class="widget widget-gallery">
						<h3 class="widget-title">Photo Gallery</h3>
						<ul class="list-inline photo-gallery clearfix">
							<!--[if BLOCK]><![endif]--><?php if($gallery): ?>
								<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $item->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
									<li><a class="gallery-img" href="#"><img class="img-responsive" src="<?php echo e(Storage::url($img)); ?>" alt="gallery photo"></a></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
							<?php else: ?>
								<small>No content yet</small>
							<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
							
						</ul> <!-- .footer-social -->
					</div> <!-- .widget widget-gallery -->
			
					 
				</div> <!-- .col-md-4 -->
			</div> <!-- .row -->
		</div> <!-- .container -->
	</section> <!-- .portfolio-section -->

</div>
<?php /**PATH /Users/user/Herd/NIPR-Frontend/NIPR/resources/views/livewire/blog/blog.blade.php ENDPATH**/ ?>