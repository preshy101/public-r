<div>
      
      <!--[if BLOCK]><![endif]--><?php if(!empty($posts)): ?>
       
      <section class="blog-section blog-style-04 section-block">
		<div class="container">
			<div class="title-block">
				<h2>Latest News</h2>
				<p>
					Stay up to date with us on our amazing news feeds
				</p>
			</div> <!-- .title-block -->
			<div class="row">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
				<div class="col-md-4">
					<div class="post-wrapper">
						<div class="image-wrapper">
							<img class="img-responsive" 
                            src="<?php echo e(Storage::url($item->image)); ?>" 
                            alt="blog image 01">
						</div> <!-- .image-wrapper -->
						<div class="post-content">
							<ul class="post-meta">
								<li><?php echo e($item->published_at->diffForHumans()); ?></li>
								<li>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                    <a class="badge badge-pill " style="background: <?php echo e($cat->bg_color); ?>; color:<?php echo e($cat->text_color); ?>" href="#">
                                        <?php echo e($cat->title); ?>

                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                </li>
							</ul>
							<h3><a wire:navigate href="/news/posts/<?php echo e($item->slug); ?>"><?php echo e($item->title); ?></a></h3>
							<p>
								<?php echo $item->getExcept(); ?>

							</p>
							<a class="btn-open" wire:navigate href="/news/posts/<?php echo e($item->slug); ?>">Read More</a>
						</div> <!-- .post-content -->
					</div> <!-- .post-wrapper -->
				</div> <!-- .col-md-4 -->
            
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
			</div> <!-- .row -->
			<div class="btn-container">
				<a wire:navigate class="btn btn-narrow" href="/news/posts">View All</a>
			</div>
			
		</div> <!-- .container -->
	</section> <!-- .blog-section -->   

    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

</div><?php /**PATH /Users/user/Herd/NIPR-Frontend/NIPR/resources/views/livewire/sections/news.blade.php ENDPATH**/ ?>