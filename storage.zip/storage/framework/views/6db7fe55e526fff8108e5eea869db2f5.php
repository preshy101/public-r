
<!--[if BLOCK]><![endif]--><?php if(!empty($president)): ?> 
   <section class="about-section section-block">
    <div class="container">
        <div class="row">
            <div class="col-md-6 img-block">
                <img class="img-responsive rounded" 
                
					src="<?php echo e(Storage::url($president->image)); ?>"  
                     style="height: 515px;"  alt="about image">  
                
              
            </div> <!-- .col-md-6 img-block -->
            <div class="col-md-6 content-block">
                <h2><span>Meet the president </span> 
                    <?php echo e(($president != null)?$president->title: "Mr President"); ?> 
                </h2>
                <p>
                    
                    <?php echo e(($president != null)?$president->description:"The Nigerian Institute of Public Relations (NIPR) was established in 1963. 
                    The body attained the status of a Chartered Institute in June 1990 through Decree No. 16 (now an Act of the National Assembly)
                     from which it derives the power and responsibility  to register members, set parameters of knowledge to acquire to qualify to 
                     practise, regulate the practice and development of the PR Profession as well monitor professional conducts through an established
                     Code of Ethics, amongst others. "); ?>

                </p>
                <p>
                    <?php echo e(($president != null)?$president->note: ""); ?>

                </p>

                        <a class="btn btn-main" wire:navigate href="/team-members">Read More</a>
          
                    </div> <!-- .col-md-6 -->
                </div> <!-- .row -->
            </div> <!-- .container -->
        </section> <!-- .about-section --> 
        <?php else: ?>
                    
                
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
         
        <!--[if BLOCK]><![endif]--><?php if(!empty($team)): ?>
        <section class="team-section team-02 mt-0 section-block">
            <div class="container">
                <div class="title-block">
                    <h2>Our Team</h2>
                    <p>
                a collective of passionate professionals committed to innovation, collaboration, and delivering excellence in every endeavor.
            </p>
        </div> <!-- .title-block -->
        <div class="row">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6">
                <div class="img-wrapper">
                    <img class="img-responsive"  
					src="<?php echo e(Storage::url($item->image)); ?>"   
                    width="485" style="height: 515px ;"  alt="team member 01">
                </div> <!-- .img-wrapper -->
                <div class="member-info" style="background-color: red; color: white" >
                    <h4><?php echo e($item->title); ?> <small><?php echo e($item->description); ?></small></h4>
                    <ul class="social-links">
                        <li><a href="#" class="facebook-link"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="twitter-link"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="google-plus-link"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="linkedin-link"><i class="fa fa-linkedin"></i></a></li>
                    </ul> <!-- .social-links -->

                </div> <!-- .member-info -->
            </div> <!-- col-lg-3 col-md-6 -->

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
             
            
        </div> <!-- .row -->
        <center> <a class="btn btn-main "  wire:navigate href="/team-members">See More</a> </center> 
    </div> <!-- .container -->
</section> <!-- .team-section -->
<?php endif; ?> <!--[if ENDBLOCK]><![endif]--><?php /**PATH /Users/user/Herd/NIPR-Frontend/NIPR/resources/views/livewire/sections/presidentMessage.blade.php ENDPATH**/ ?>