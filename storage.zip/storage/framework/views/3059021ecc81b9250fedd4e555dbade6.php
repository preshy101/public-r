<p
    <?php echo e($attributes->class(['fi-section-header-description text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /Users/user/Herd/NIPR-Frontend/NIPR/vendor/filament/support/src/../resources/views/components/section/description.blade.php ENDPATH**/ ?>