<div>
    <section class="hero-area">
		<div class="page-title-banner" >
			<div class="container">
				<div class="content-wrapper">
					<h2>Resources </h2>
					<ul class="bread-crumb">
						<li><a href="/">Home</a></li> 
						<li><a href="/resources/up-coming-events">Events</a></li>
						<li><a href="#">
                            <!--[if BLOCK]><![endif]--><?php if($event): ?>
                             <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($item->title); ?>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </a></li>
					</ul>
				</div> <!-- .content-wrapper -->
			</div> <!-- .container -->
		</div> <!-- .page-title-banner -->
	</section> <!-- .hero-area -->
    
	<section class="portfolio-details-section page-content">
		<div class="container">
			
			<div class="row">
                <!--[if BLOCK]><![endif]--><?php if($event): ?>
             <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
				<div class="col-md-12">
					<div class="item-wrapper">
						<img class="portfolio-f-img img-responsive" src="<?php echo e(Storage::url($item->image)); ?>" alt="event image">
					</div> <!-- .item-wrapper -->
				</div> <!-- .portfolio-item -->
				<div class="col-md-8">
					<h2 class="portfolio-title"><?php echo e($item->title); ?></h2>
					<div class="portfolio-details-content">
						<p style="text-align: justify">
							<?php echo e($item->description); ?> <br>
                            <?php echo $item->fullText; ?>

						</p>
					</div> <!-- .project-details-content -->
				</div> <!-- .col-md-8 -->
				<div class="col-md-4">
					<div class="portfolio-meta">
						<ul>
							<li><strong>Start Date</strong> <?php echo e($item->startDate); ?></li>
							<li><strong>End Date</strong><?php echo e($item->endDate); ?></li>
							<li><strong>Note</strong></li>
							<li><?php echo e($item->note); ?></li>
						</ul>
					</div> <!-- .portfolio-meta -->
				</div> <!-- .col-md-4 -->
			</div> <!-- .row -->
            <br>
            <br>
            <br>
            <br>
			<div class="related-project-block">
				<h3 class="block-title">Some Moment Captured</h3>
				<div class="portfolio-section portfolio-style-02">
					<div class="row">
                        
                        <?php if(count($item->imageVideo) > 0): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $item->imageVideo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $item->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventImages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
						<div class="col-sm-4 portfolio-item">
							<div class="item-wrapper">
								<img class="img-responsive" src="<?php echo e(Storage::url($eventImages)); ?>" alt="event image">
								<div class="portfolio-details">
									<a class="portfolio-popup" href="<?php echo e(Storage::url($eventImages)); ?>"><span class="zoom-icon"></span></a>
									<div class="hover-content">
										<h3><a href="#"><?php echo e($item->note); ?></a></h3>
										<p><?php echo e($item->alternativeText); ?></p>
									</div><!-- .hover-content -->
								</div> <!-- .portfolio-details -->
							</div> <!-- .item-wrapper -->
						</div> <!-- .portfolio-item -->

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
						 
					</div> <!-- .row -->
				</div> <!-- .portfolio-section portfolio-style-02 -->
			</div> <!-- .related-project-block --> 
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
		</div> <!-- .container -->
	</section> <!-- .portfolio-section -->

</div>
<?php /**PATH /Users/user/Herd/NIPR-Frontend/NIPR/resources/views/livewire/resources/view-event.blade.php ENDPATH**/ ?>