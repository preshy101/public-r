<div> 

    <section class="hero-area">
		<div class="page-title-banner" >
			<div class="container">
				<div class="content-wrapper">
					<h2>Resources </h2>
					<ul class="bread-crumb">
						<li><a href="/">Home</a></li> 
						<li><a href="#">Events</a></li>
					</ul>
				</div> <!-- .content-wrapper -->
			</div> <!-- .container -->
		</div> <!-- .page-title-banner -->
	</section> <!-- .hero-area -->
    <section class="blog-section blog-post-11 page-content">
		<div class="container">
			
			<h1 class="entry-title"><a style="color: red" href="#">Up Coming Events</a></h1>
			<p class="lead">enlightenment, outreach and wonderful events gallery</p>
			<br>
            <section class="blog-section blog-post-07 page-content">
                <div class="container">
                    
                    <div class="row blog-posts">
                        <!--[if BLOCK]><![endif]--><?php if($events): ?> 
				        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <div class="col-md-4">
                            <div class="post-wrapper post-grid">
                                <div class="image-wrapper">
                                    <img class="img-responsive" src="<?php echo e(Storage::url($item->image)); ?>" alt="event image 00">
                                </div> <!-- .image-wrapper -->
                                <div class="post-content">
                                    <ul class="post-meta">
                                        <li><?php echo e($item->created_at->diffForHumans()); ?></li>
                                        
                                    </ul>
                                    <h3 class="entry-title"><a href="/resources/up-coming-events/<?php echo e($item->id); ?>"><?php echo e($item->title); ?></a></h3>
                                    <div class="entry-content">
                                        <p>
                                            <?php echo e($item->description); ?>

                                        </p>
                                    </div>
                                    <a wire:navigate class="btn-open" href="/resources/up-coming-events/<?php echo e($item->id); ?>">Read More</a>
                                </div> <!-- .post-content -->
                            </div> <!-- .post-wrapper -->
                        </div> <!-- .col-md-4 -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        <?php echo e($events->onEachSide(1)->links()); ?>

                    </div> <!-- .row -->
                    
                </div> <!-- .container -->
            </section> <!-- .portfolio-section -->        
		</div> <!-- .container -->
		
	</section> <!-- .portfolio-section --> 
</div>
<?php /**PATH /Users/user/Herd/NIPR-Frontend/NIPR/resources/views/livewire/resources/resource-event.blade.php ENDPATH**/ ?>